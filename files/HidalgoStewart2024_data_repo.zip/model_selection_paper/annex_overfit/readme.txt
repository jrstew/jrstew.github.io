The main file in this folder is par_ergm.R
The parameters for this script are in params.R
The output goes to the folder /res

You want to make sure that you are loading the seeds file, first and foremost.
Once run, one can run the file reports.R, and from there the plot file in the /reports folder
