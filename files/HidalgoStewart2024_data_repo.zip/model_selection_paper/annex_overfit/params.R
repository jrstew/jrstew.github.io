M<- c(100,1000,10000)
Sizes <-c(25,50,75)
Tr<- c(5,10,15)/100 #gwesp parameters
