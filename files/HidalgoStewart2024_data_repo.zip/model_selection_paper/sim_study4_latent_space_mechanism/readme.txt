Main file is par_latent_space.R
Make sure to load seeds firt

outputs are stored in /res folder

File reports.R summarizes results and stores result in /results folder.
A plot file can be run from there

