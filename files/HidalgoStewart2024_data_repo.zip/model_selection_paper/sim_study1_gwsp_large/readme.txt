The main file is par_ergm.R
Load seeds first!

Output is stored in /res folder
Run report.R to summarize outputs and save outputs in /results folder
Plot code is in the same folder

