The main file is par_ergm.R
Load seeds first!

Output is stored in /res folder
Run report.R to summarize results and save output in /results folder
Plot code is in the same folder

