
Models must be fitted first in the /models folder.
Then simulations and plots must be run from /preds folder
