
First run sims.R and then preds.R, then R plot file



