Main file is par_latent.R
Make sure to load seeds first

outputs are stored in /res folder
File report.R summarizes results and stores output at /reports folder
From there, a plot file can be run



