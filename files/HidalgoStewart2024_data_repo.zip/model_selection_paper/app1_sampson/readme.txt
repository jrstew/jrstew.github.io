Main file is app_sampson_dir.R
